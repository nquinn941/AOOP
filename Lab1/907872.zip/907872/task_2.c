
#include <stdio.h>
#include "factorial.h"

int main(int argc, char* argv[]){

	printf("5! is %d\n", factorial(5));
	return 0;
}