#ifndef __FACTORIAL__
#define __FACTORIAL__

int factorial(int value);

#endif